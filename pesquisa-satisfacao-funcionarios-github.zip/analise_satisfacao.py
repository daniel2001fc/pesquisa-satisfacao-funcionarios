"""
Projeto: Pesquisa de Satisfação de Funcionários — Acme Corp
Objetivo:
1. Manter somente a resposta mais recente de cada funcionário.
2. Calcular quantidade e percentual por nota (1 a 5).
3. Calcular a nota média e agrupar satisfação positiva, neutra e negativa.
4. Gerar arquivos de resultados e um gráfico.
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

PASTA_PROJETO = Path(__file__).resolve().parent
ARQUIVO_ENTRADA = PASTA_PROJETO / "employee_satisfaction_survey.csv"
PASTA_RESULTADOS = PASTA_PROJETO / "resultados"
PASTA_RESULTADOS.mkdir(exist_ok=True)

ROTULOS = {
    1: "Muito insatisfeito",
    2: "Insatisfeito",
    3: "Neutro",
    4: "Satisfeito",
    5: "Muito satisfeito",
}


def main():
    # Carrega os dados e converte o timestamp para data/hora.
    dados = pd.read_csv(ARQUIVO_ENTRADA)
    dados["Timestamp"] = pd.to_datetime(dados["Timestamp"], errors="coerce")
    dados["Satisfaction"] = pd.to_numeric(dados["Satisfaction"], errors="coerce")

    # Remove linhas sem identificador, data ou nota válida.
    dados = dados.dropna(subset=["Email", "Timestamp", "Satisfaction"])
    dados = dados[dados["Satisfaction"].isin([1, 2, 3, 4, 5])].copy()

    # Ordena por data e mantém apenas o envio mais recente de cada e-mail.
    ultimas_respostas = (
        dados.sort_values(["Email", "Timestamp"])
        .drop_duplicates(subset="Email", keep="last")
        .sort_values(["Satisfaction", "Email"])
    )

    # Conta as notas de 1 a 5, incluindo notas que eventualmente tenham zero respostas.
    contagens = (
        ultimas_respostas["Satisfaction"]
        .value_counts()
        .reindex([1, 2, 3, 4, 5], fill_value=0)
    )
    total_funcionarios = len(ultimas_respostas)

    resumo = pd.DataFrame({
        "Nota": [1, 2, 3, 4, 5],
        "Nivel_de_satisfacao": [ROTULOS[n] for n in [1, 2, 3, 4, 5]],
        "Quantidade_funcionarios": [int(contagens[n]) for n in [1, 2, 3, 4, 5]],
        "Percentual": [
            (contagens[n] / total_funcionarios * 100) if total_funcionarios else 0
            for n in [1, 2, 3, 4, 5]
        ],
    })

    nota_media = ultimas_respostas["Satisfaction"].mean()
    satisfeitos = int(ultimas_respostas["Satisfaction"].isin([4, 5]).sum())
    neutros = int(ultimas_respostas["Satisfaction"].eq(3).sum())
    insatisfeitos = int(ultimas_respostas["Satisfaction"].isin([1, 2]).sum())

    # Salva resultados em CSV.
    resumo.to_csv(PASTA_RESULTADOS / "resumo_satisfacao.csv", index=False, encoding="utf-8-sig")
    ultimas_respostas.assign(
        Timestamp=ultimas_respostas["Timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")
    ).to_csv(
        PASTA_RESULTADOS / "ultimas_respostas_por_funcionario.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Cria gráfico de barras.
    plt.figure(figsize=(9, 5))
    barras = plt.bar(
        [str(n) for n in [1, 2, 3, 4, 5]],
        [int(contagens[n]) for n in [1, 2, 3, 4, 5]],
    )
    plt.title("Distribuição da satisfação dos funcionários")
    plt.xlabel("Nota de satisfação (1 = muito insatisfeito; 5 = muito satisfeito)")
    plt.ylabel("Quantidade de funcionários")
    plt.bar_label(barras, padding=3)
    plt.tight_layout()
    plt.savefig(PASTA_RESULTADOS / "grafico_distribuicao_satisfacao.png", dpi=160)
    plt.close()

    print("=== RESULTADO DA PESQUISA DE SATISFAÇÃO ===")
    print(f"Registros válidos analisados antes da deduplicação: {len(dados)}")
    print(f"Funcionários únicos: {total_funcionarios}")
    print(f"Nota média: {nota_media:.2f}/5")
    print(f"Satisfeitos (notas 4 e 5): {satisfeitos} ({satisfeitos / total_funcionarios * 100:.2f}%)")
    print(f"Neutros (nota 3): {neutros} ({neutros / total_funcionarios * 100:.2f}%)")
    print(f"Insatisfeitos (notas 1 e 2): {insatisfeitos} ({insatisfeitos / total_funcionarios * 100:.2f}%)")
    print()
    print(resumo.to_string(index=False))
    print(f"\nArquivos gerados na pasta: {PASTA_RESULTADOS}")


if __name__ == "__main__":
    main()
